import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { GoogleGenAI } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '10mb' }));

// Serve static public folder for audio & assets
app.use(express.static(path.resolve(__dirname, 'public')));

// In-Memory Database Store with Algerian Seed Data
interface Store {
  users: any[];
  vehicles: any[];
  providers: any[];
  workshops: any[];
  sparePartsStores: any[];
  requests: any[];
  reviews: any[];
  notifications: any[];
}

const store: Store = {
  users: [
    {
      id: 'usr_driver_1',
      name: 'Sofiane Belkacem',
      phone: '0550123456',
      password: 'password123',
      role: 'driver',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80',
      wilaya: 'Alger',
      createdAt: '2026-01-15T10:00:00Z'
    },
    {
      id: 'usr_provider_1',
      name: 'Khaled Dépannage',
      phone: '0661987654',
      password: 'password123',
      role: 'provider',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=256&q=80',
      wilaya: 'Alger',
      createdAt: '2026-01-10T08:30:00Z'
    },
    {
      id: 'usr_admin_1',
      name: 'Direction Dépannage.DZ',
      phone: '0770000000',
      password: 'adminpassword',
      role: 'admin',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=256&q=80',
      wilaya: 'Alger',
      createdAt: '2025-12-01T00:00:00Z'
    }
  ],
  vehicles: [
    {
      id: 'veh_1',
      userId: 'usr_driver_1',
      brand: 'Renault',
      model: 'Clio 4 GT Line',
      year: 2019,
      engineType: 'Diesel',
      registrationNumber: '01452-119-16',
      isDefault: true
    },
    {
      id: 'veh_2',
      userId: 'usr_driver_1',
      brand: 'Volkswagen',
      model: 'Golf 7 R-Line',
      year: 2020,
      engineType: 'Essence',
      registrationNumber: '02890-120-16',
      isDefault: false
    }
  ],
  providers: [
    {
      id: 'prv_1',
      userId: 'usr_provider_1',
      businessName: 'Dépannage & Remorquage El Bahdja 24/7',
      providerType: 'tow_truck',
      phone: '0661987654',
      wilaya: 'Alger',
      commune: 'Bab Ezzouar',
      address: 'Route Nationale 5, Bab Ezzouar, Alger',
      lat: 36.7215,
      lng: 3.1852,
      isAvailable: true,
      rating: 4.9,
      reviewCount: 38,
      workingHours: '24h/24 7j/7',
      services: ['Remorquage Plateau', 'Treuillage sous-sol', 'Dépannage autoroute', 'Changement roue'],
      description: 'Service d’assistance rapide avec 3 camions plateaux neufs équipés de treuils hydrauliques. Intervention sur Alger, Blida, Boumerdès et autoroute Est-Ouest.',
      photo: 'https://images.unsplash.com/photo-1562920616-092576b53ea1?auto=format&fit=crop&w=600&q=80',
      vehicleModel: 'Iveco Daily Plateau Basculant 2022',
      basePriceDzd: 3500,
      pricePerKmDzd: 150,
      approvedByAdmin: true
    },
    {
      id: 'prv_2',
      userId: 'usr_provider_2',
      businessName: 'SOS Mécanique Mobile Alger Express',
      providerType: 'mobile_mechanic',
      phone: '0555334411',
      wilaya: 'Alger',
      commune: 'Chéraga',
      address: 'Lotissement Kaidi, Chéraga, Alger',
      lat: 36.7644,
      lng: 2.9587,
      isAvailable: true,
      rating: 4.8,
      reviewCount: 29,
      workingHours: '06:00 - 00:00 (7j/7)',
      services: ['Diagnostic Valise Scanner', 'Batterie & Démarrage', 'Courroies & Durites', 'Freinage d’urgence'],
      description: 'Mécanicien mobile certifié avec fourgon atelier tout équipé (compresseur, valise multimarque Bosch, booster 12V/24V, outillage complet).',
      photo: 'https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&w=600&q=80',
      vehicleModel: 'Peugeot Partner Atelier Mobile',
      basePriceDzd: 2500,
      pricePerKmDzd: 100,
      approvedByAdmin: true
    },
    {
      id: 'prv_3',
      userId: 'usr_provider_3',
      businessName: 'Remorquage Wahran Étoile',
      providerType: 'tow_truck',
      phone: '0770112233',
      wilaya: 'Oran',
      commune: 'Es Sénia',
      address: 'Zone Industrielle Es Sénia, Oran',
      lat: 35.6512,
      lng: -0.6214,
      isAvailable: true,
      rating: 4.7,
      reviewCount: 22,
      workingHours: '24h/24 7j/7',
      services: ['Remorquage longue distance', 'Traction véhicules 4x4', 'Dépannage crevaison'],
      description: 'Prise en charge de tout type de véhicule sur la wilaya d’Oran et axes autoroutiers Ouest.',
      photo: 'https://images.unsplash.com/photo-1541899481282-d53bffe3c35d?auto=format&fit=crop&w=600&q=80',
      vehicleModel: 'Renault Midlum Dépanneuse Lourde',
      basePriceDzd: 4000,
      pricePerKmDzd: 160,
      approvedByAdmin: true
    },
    {
      id: 'prv_4',
      userId: 'usr_provider_4',
      businessName: 'Cirta Auto Dépannage & Électricité',
      providerType: 'electrician',
      phone: '0662445566',
      wilaya: 'Constantine',
      commune: 'Ali Mendjeli',
      address: 'UV 05, Ville Nouvelle Ali Mendjeli, Constantine',
      lat: 36.2625,
      lng: 6.5741,
      isAvailable: true,
      rating: 4.9,
      reviewCount: 17,
      workingHours: '07:00 - 22:00',
      services: ['Alternateur & Démarreur', 'Fusibles & Faisceau', 'Programmation clés & Anti-démarrage'],
      description: 'Spécialiste pannes électriques et électroniques sur place à Constantine et ses environs.',
      photo: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=600&q=80',
      vehicleModel: 'Renault Kangoo Service',
      basePriceDzd: 2000,
      pricePerKmDzd: 80,
      approvedByAdmin: true
    },
    {
      id: 'prv_5',
      userId: 'usr_provider_5',
      businessName: 'SOS Pneu & Batterie Mitidja',
      providerType: 'tire_battery',
      phone: '0560778899',
      wilaya: 'Blida',
      commune: 'Boufarik',
      address: 'Route de Soumaâ, Boufarik, Blida',
      lat: 36.5731,
      lng: 2.9123,
      isAvailable: true,
      rating: 4.6,
      reviewCount: 14,
      workingHours: '24h/24 7j/7',
      services: ['Remplacement batterie sur place', 'Réparation crevaison champignon', 'Gonflage azote'],
      description: 'Intervention immédiate avec stock de batteries neuves garanties 12 mois (Varta, Tudor, Enersys).',
      photo: 'https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=600&q=80',
      vehicleModel: 'Citroën Berlingo Assistance',
      basePriceDzd: 1800,
      pricePerKmDzd: 70,
      approvedByAdmin: true
    }
  ],
  workshops: [
    {
      id: 'wkp_1',
      name: 'Garage Mécanique Moderne El Harrach',
      phone: '023847291',
      wilaya: 'Alger',
      commune: 'El Harrach',
      address: 'Boulevard Bougara, El Harrach, Alger',
      lat: 36.7188,
      lng: 3.1328,
      categories: ['Mécanique générale', 'Diagnostic scanner', 'Climatisation', 'Freinage'],
      supportedBrands: ['Renault', 'Dacia', 'Peugeot', 'Volkswagen', 'Hyundai'],
      openNow: true,
      workingHours: 'Samedi - Jeudi : 08:00 - 18:30',
      rating: 4.8,
      reviewCount: 42,
      photo: 'https://images.unsplash.com/photo-1486006920555-c77dce18193b?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'wkp_2',
      name: 'Centre Auto Kouba Précision',
      phone: '023771122',
      wilaya: 'Alger',
      commune: 'Kouba',
      address: 'Vieux Kouba, Rue Mohamed Belouizdad, Alger',
      lat: 36.7291,
      lng: 3.0822,
      categories: ['Moteur', 'Boîte de vitesse', 'Suspension', 'Tôlerie & Peinture'],
      supportedBrands: ['Audi', 'Volkswagen', 'Seat', 'Skoda', 'BMW', 'Mercedes'],
      openNow: true,
      workingHours: '08:00 - 19:00',
      rating: 4.9,
      reviewCount: 65,
      photo: 'https://images.unsplash.com/photo-1517524008697-84bbe3c3fd98?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'wkp_3',
      name: 'Atelier Mécanique Maraval Oran',
      phone: '041334455',
      wilaya: 'Oran',
      commune: 'Maraval',
      address: 'Boulevard Millenium, Maraval, Oran',
      lat: 35.6841,
      lng: -0.6521,
      categories: ['Diagnostic scanner', 'Mécanique générale', 'Courroies', 'Injecteurs'],
      supportedBrands: ['Toyota', 'Kia', 'Hyundai', 'Peugeot', 'Renault'],
      openNow: true,
      workingHours: '08:00 - 18:00',
      rating: 4.7,
      reviewCount: 31,
      photo: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=600&q=80'
    },
    {
      id: 'wkp_4',
      name: 'Garage Al-Amana Sétif Ain Romane',
      phone: '036829100',
      wilaya: 'Sétif',
      commune: 'Sétif Centre',
      address: 'Cité Ain Romane, Sétif',
      lat: 36.195,
      lng: 5.418,
      categories: ['Mécanique générale', 'Électricité', 'Freinage & Pneus'],
      supportedBrands: ['Toutes Marques', 'Renault', 'Peugeot', 'Dacia'],
      openNow: true,
      workingHours: '08:00 - 18:00',
      rating: 4.8,
      reviewCount: 26,
      photo: 'https://images.unsplash.com/photo-1504222490345-c075b6008014?auto=format&fit=crop&w=600&q=80'
    }
  ],
  sparePartsStores: [
    {
      id: 'sps_1',
      name: 'EURL Pièces Auto Algérie - Bab Ezzouar',
      phone: '023831122',
      wilaya: 'Alger',
      commune: 'Bab Ezzouar',
      address: 'En face CUB 1, Bab Ezzouar, Alger',
      lat: 36.7192,
      lng: 3.1784,
      categories: ['Freinage', 'Filtration', 'Suspension', 'Distribution', 'Batteries'],
      supportedBrands: ['Renault', 'Peugeot', 'Dacia', 'Volkswagen', 'Hyundai'],
      openNow: true,
      workingHours: '08:00 - 19:30',
      rating: 4.8,
      reviewCount: 51,
      photo: 'https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?auto=format&fit=crop&w=600&q=80',
      inventorySamples: [
        { name: 'Kit Plaquettes de Frein avant Bosch', ref: 'BOS-0986424795', brand: 'Renault Clio 4 / Captur', priceDzd: 4200, inStock: true },
        { name: 'Batterie Varta Blue Dynamic 12V 70Ah', ref: 'VAR-570412063', brand: 'Multimarque Diesel', priceDzd: 16500, inStock: true },
        { name: 'Kit Distribution + Pompe à eau Gates', ref: 'GAT-KP15671XS', brand: '1.5 dCi Renault / Dacia', priceDzd: 14800, inStock: true },
        { name: 'Filtre à Huile Mann Filter', ref: 'MAN-W79', brand: 'Renault / Nissan', priceDzd: 1200, inStock: true },
        { name: 'Amortisseurs avant Monroe (Paire)', ref: 'MON-G7328', brand: 'Peugeot 208 / 2008', priceDzd: 18500, inStock: true },
        { name: 'Démarreur Valéo 12V 1.4kW', ref: 'VAL-438183', brand: 'Volkswagen Golf 7 TDI', priceDzd: 28000, inStock: true }
      ]
    },
    {
      id: 'sps_2',
      name: 'Comptoir Pièces Détachées Ouest - Oran Gambetta',
      phone: '041421100',
      wilaya: 'Oran',
      commune: 'Gambetta',
      address: 'Boulevard Colonel Lotfi, Gambetta, Oran',
      lat: 35.7062,
      lng: -0.6312,
      categories: ['Moteur', 'Éclairage & Phares', 'Embrayage', 'Huiles & Lubrifiants'],
      supportedBrands: ['Toyota', 'Hyundai', 'Kia', 'Nissan', 'Mitsubishi'],
      openNow: true,
      workingHours: '08:30 - 19:00',
      rating: 4.7,
      reviewCount: 38,
      photo: 'https://images.unsplash.com/photo-1508974239320-0a029497e820?auto=format&fit=crop&w=600&q=80',
      inventorySamples: [
        { name: 'Kit Embrayage Luk complet', ref: 'LUK-622322300', brand: 'Hyundai Accent / i20', priceDzd: 22000, inStock: true },
        { name: 'Optique Phare avant d’origine', ref: 'TOY-81110-0D680', brand: 'Toyota Yaris 2018', priceDzd: 34000, inStock: true },
        { name: 'Huile Moteur Total Quartz Ineo 5W30 5L', ref: 'TOT-INEO-5L', brand: 'Universel Norme ACEA C3', priceDzd: 6800, inStock: true },
        { name: 'Bougies d’allumage NGK Iridium (x4)', ref: 'NGK-ILKAR7L11', brand: 'Toyota / Nissan Essence', priceDzd: 5600, inStock: true }
      ]
    },
    {
      id: 'sps_3',
      name: 'Magasin Al-Nadjah Pièces Auto Constantine',
      phone: '031923344',
      wilaya: 'Constantine',
      commune: 'Sidi Mabrouk',
      address: 'Route de Batna, Sidi Mabrouk, Constantine',
      lat: 36.354,
      lng: 6.621,
      categories: ['Carrosserie', 'Radiateur & Refroidissement', 'Électricité'],
      supportedBrands: ['Peugeot', 'Citroën', 'Renault', 'Volkswagen'],
      openNow: true,
      workingHours: '08:00 - 18:30',
      rating: 4.6,
      reviewCount: 24,
      photo: 'https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=600&q=80',
      inventorySamples: [
        { name: 'Radiateur de refroidissement NRF', ref: 'NRF-53544', brand: 'Peugeot 301 / C-Elysée', priceDzd: 11500, inStock: true },
        { name: 'Pompe à carburant immergée Bosch', ref: 'BOS-0580313057', brand: 'Renault Megane 3', priceDzd: 17000, inStock: true },
        { name: 'Alternateur 140A Valéo', ref: 'VAL-439542', brand: 'Audi A3 / Golf 6', priceDzd: 32500, inStock: false }
      ]
    }
  ],
  requests: [
    {
      id: 'req_101',
      driverId: 'usr_driver_1',
      driverName: 'Sofiane Belkacem',
      driverPhone: '0550123456',
      vehicle: {
        brand: 'Renault',
        model: 'Clio 4 GT Line',
        year: 2019,
        registrationNumber: '01452-119-16',
        engineType: 'Diesel'
      },
      problemType: 'towing',
      description: 'Panne d\'embrayage sur l\'autoroute Est-Ouest à hauteur de la sortie Bab Ezzouar. Véhicule immobilisé sur la bande d\'arrêt d\'urgence.',
      photos: [
        'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=400&q=80'
      ],
      status: 'ON_THE_WAY',
      serviceType: 'tow_truck',
      pickupLocation: {
        lat: 36.7215,
        lng: 3.1852,
        address: 'Autoroute Est-Ouest, Sortie Bab Ezzouar, Alger',
        wilaya: 'Alger'
      },
      destinationLocation: {
        lat: 36.7188,
        lng: 3.1328,
        address: 'Garage Mécanique Moderne, El Harrach, Alger',
        wilaya: 'Alger'
      },
      providerId: 'prv_1',
      providerName: 'Dépannage & Remorquage El Bahdja 24/7',
      providerPhone: '0661987654',
      providerType: 'tow_truck',
      providerLocation: {
        lat: 36.7290,
        lng: 3.1700
      },
      estimatedArrivalMinutes: 8,
      estimatedPriceDzd: 4500,
      createdAt: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
      acceptedAt: new Date(Date.now() - 10 * 60 * 1000).toISOString()
    },
    {
      id: 'req_100',
      driverId: 'usr_driver_1',
      driverName: 'Sofiane Belkacem',
      driverPhone: '0550123456',
      vehicle: {
        brand: 'Renault',
        model: 'Clio 4 GT Line',
        year: 2019,
        registrationNumber: '01452-119-16',
        engineType: 'Diesel'
      },
      problemType: 'battery',
      description: 'Batterie à plat au parking du Centre Commercial Bab Ezzouar.',
      photos: [],
      status: 'COMPLETED',
      serviceType: 'mobile_mechanic',
      pickupLocation: {
        lat: 36.7145,
        lng: 3.1901,
        address: 'Parking Centre Commercial Bab Ezzouar, Alger',
        wilaya: 'Alger'
      },
      providerId: 'prv_2',
      providerName: 'SOS Mécanique Mobile Alger Express',
      providerPhone: '0555334411',
      providerType: 'mobile_mechanic',
      estimatedArrivalMinutes: 0,
      estimatedPriceDzd: 2500,
      finalPriceDzd: 2500,
      createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
      completedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000 + 45 * 60 * 1000).toISOString(),
      rating: 5,
      reviewText: 'Dépannage très rapide avec booster professionnel. Arrivé en moins de 20 minutes, merci beaucoup !'
    }
  ],
  reviews: [
    {
      id: 'rev_1',
      providerId: 'prv_1',
      userId: 'usr_driver_1',
      userName: 'Sofiane B.',
      rating: 5,
      comment: 'Excellent service de remorquage sur l\'autoroute. Camion moderne et chauffeur très courtois.',
      date: '2026-02-14',
      vehicleInfo: 'Renault Clio 4'
    },
    {
      id: 'rev_2',
      providerId: 'prv_1',
      userId: 'usr_driver_99',
      userName: 'Amine K.',
      rating: 5,
      comment: 'Treuillage parfait dans un sous-sol difficile d\'accès à Kouba. Prix raisonnable.',
      date: '2026-02-10',
      vehicleInfo: 'Peugeot 3008'
    },
    {
      id: 'rev_3',
      providerId: 'prv_2',
      userId: 'usr_driver_1',
      userName: 'Sofiane B.',
      rating: 5,
      comment: 'Dépannage très rapide avec booster professionnel. Arrivé en moins de 20 minutes, merci beaucoup !',
      date: '2026-02-05',
      vehicleInfo: 'Renault Clio 4'
    }
  ],
  notifications: [
    {
      id: 'notif_1',
      userId: 'usr_driver_1',
      titleFr: 'Dépanneur en route !',
      titleAr: 'المنقذ في الطريق إليك!',
      bodyFr: 'Dépannage & Remorquage El Bahdja 24/7 est en route vers votre position. Arrivée estimée dans 8 min.',
      bodyAr: 'شاحنة النجدة متوجهة نحوك الآن. الوقت المتوقع للوصول: 8 دقائق.',
      type: 'status_update',
      read: false,
      timestamp: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
      requestId: 'req_101'
    }
  ]
};

// ======================== API ROUTES ========================

// Auth: Login
app.post('/api/auth/login', (req: Request, res: Response) => {
  const { phone, password } = req.body;
  const user = store.users.find(u => u.phone === phone);
  if (!user || user.password !== password) {
    return res.status(401).json({ error: 'Numéro de téléphone ou mot de passe incorrect' });
  }
  return res.json({ user });
});

// Auth: Register
app.post('/api/auth/register', (req: Request, res: Response) => {
  const { name, phone, password, role = 'driver', wilaya = 'Alger' } = req.body;
  if (!name || !phone || !password) {
    return res.status(400).json({ error: 'Tous les champs obligatoires doivent être renseignés' });
  }
  const existing = store.users.find(u => u.phone === phone);
  if (existing) {
    return res.status(400).json({ error: 'Ce numéro de téléphone est déjà enregistré' });
  }

  const newUser = {
    id: `usr_${Date.now()}`,
    name,
    phone,
    password,
    role,
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=256&q=80',
    wilaya,
    createdAt: new Date().toISOString()
  };
  store.users.push(newUser);

  // If role is provider, register provider stub
  if (role === 'provider') {
    const newProvider = {
      id: `prv_${Date.now()}`,
      userId: newUser.id,
      businessName: `${name} Dépannage & Assistance`,
      providerType: 'tow_truck',
      phone,
      wilaya,
      commune: 'Centre',
      address: `${wilaya}, Algérie`,
      lat: 36.7538,
      lng: 3.0588,
      isAvailable: true,
      rating: 5.0,
      reviewCount: 0,
      workingHours: '24h/24 7j/7',
      services: ['Remorquage', 'Dépannage d\'urgence'],
      description: 'Nouveau prestataire d\'assistance routière certifié.',
      photo: 'https://images.unsplash.com/photo-1562920616-092576b53ea1?auto=format&fit=crop&w=600&q=80',
      basePriceDzd: 3000,
      pricePerKmDzd: 150,
      approvedByAdmin: true
    };
    store.providers.push(newProvider);
  }

  return res.status(201).json({ user: newUser });
});

// Auth: Update Profile
app.put('/api/auth/profile', (req: Request, res: Response) => {
  const { id, name, phone, wilaya, avatar } = req.body;
  const user = store.users.find(u => u.id === id);
  if (!user) return res.status(404).json({ error: 'Utilisateur non trouvé' });

  if (name) user.name = name;
  if (phone) user.phone = phone;
  if (wilaya) user.wilaya = wilaya;
  if (avatar) user.avatar = avatar;

  return res.json({ user });
});

// Vehicles API
app.get('/api/vehicles', (req: Request, res: Response) => {
  const userId = req.query.userId as string;
  const list = userId ? store.vehicles.filter(v => v.userId === userId) : store.vehicles;
  return res.json(list);
});

app.post('/api/vehicles', (req: Request, res: Response) => {
  const { userId, brand, model, year, engineType, registrationNumber } = req.body;
  if (!brand || !model || !registrationNumber) {
    return res.status(400).json({ error: 'Marque, modèle et matricule requis' });
  }
  const newVeh = {
    id: `veh_${Date.now()}`,
    userId: userId || 'usr_driver_1',
    brand,
    model,
    year: Number(year) || 2020,
    engineType: engineType || 'Essence',
    registrationNumber,
    isDefault: store.vehicles.filter(v => v.userId === userId).length === 0
  };
  store.vehicles.push(newVeh);
  return res.status(201).json(newVeh);
});

app.delete('/api/vehicles/:id', (req: Request, res: Response) => {
  const id = req.params.id;
  store.vehicles = store.vehicles.filter(v => v.id !== id);
  return res.json({ success: true });
});

// Providers API
app.get('/api/providers', (req: Request, res: Response) => {
  const { type, wilaya } = req.query;
  let list = [...store.providers];
  if (type) list = list.filter(p => p.providerType === type);
  if (wilaya) list = list.filter(p => p.wilaya.toLowerCase() === String(wilaya).toLowerCase());
  return res.json(list);
});

app.get('/api/providers/:id', (req: Request, res: Response) => {
  const p = store.providers.find(item => item.id === req.params.id);
  if (!p) return res.status(404).json({ error: 'Prestataire non trouvé' });
  return res.json(p);
});

app.put('/api/providers/:id/status', (req: Request, res: Response) => {
  const p = store.providers.find(item => item.id === req.params.id);
  if (!p) return res.status(404).json({ error: 'Prestataire non trouvé' });
  p.isAvailable = req.body.isAvailable !== undefined ? req.body.isAvailable : !p.isAvailable;
  return res.json(p);
});

app.put('/api/providers/:id/location', (req: Request, res: Response) => {
  const p = store.providers.find(item => item.id === req.params.id);
  if (!p) return res.status(404).json({ error: 'Prestataire non trouvé' });
  const { lat, lng } = req.body;
  if (lat && lng) {
    p.lat = lat;
    p.lng = lng;
  }
  return res.json(p);
});

// Workshops API
app.get('/api/workshops', (req: Request, res: Response) => {
  const { query, wilaya, category } = req.query;
  let list = [...store.workshops];
  if (wilaya) {
    list = list.filter(w => w.wilaya.toLowerCase() === String(wilaya).toLowerCase());
  }
  if (category) {
    list = list.filter(w => w.categories.some((c: string) => c.toLowerCase().includes(String(category).toLowerCase())));
  }
  if (query) {
    const q = String(query).toLowerCase();
    list = list.filter(w =>
      w.name.toLowerCase().includes(q) ||
      w.commune.toLowerCase().includes(q) ||
      w.supportedBrands.some((b: string) => b.toLowerCase().includes(q))
    );
  }
  return res.json(list);
});

// Spare Parts Stores API
app.get('/api/spare-parts', (req: Request, res: Response) => {
  const { query, wilaya } = req.query;
  let list = [...store.sparePartsStores];
  if (wilaya) {
    list = list.filter(s => s.wilaya.toLowerCase() === String(wilaya).toLowerCase());
  }
  if (query) {
    const q = String(query).toLowerCase();
    list = list.filter(s =>
      s.name.toLowerCase().includes(q) ||
      s.commune.toLowerCase().includes(q) ||
      s.categories.some((c: string) => c.toLowerCase().includes(q)) ||
      s.inventorySamples.some((i: any) =>
        i.name.toLowerCase().includes(q) ||
        i.ref.toLowerCase().includes(q) ||
        i.brand.toLowerCase().includes(q)
      )
    );
  }
  return res.json(list);
});

// Requests API
app.get('/api/requests', (req: Request, res: Response) => {
  const { driverId, providerId, status } = req.query;
  let list = [...store.requests];
  if (driverId) list = list.filter(r => r.driverId === driverId);
  if (providerId) list = list.filter(r => r.providerId === providerId);
  if (status) list = list.filter(r => r.status === status);
  // Sort latest first
  list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  return res.json(list);
});

app.get('/api/requests/:id', (req: Request, res: Response) => {
  const reqItem = store.requests.find(r => r.id === req.params.id);
  if (!reqItem) return res.status(404).json({ error: 'Demande non trouvée' });
  return res.json(reqItem);
});

app.post('/api/requests', (req: Request, res: Response) => {
  const {
    driverId,
    driverName,
    driverPhone,
    vehicle,
    problemType,
    description,
    photos = [],
    serviceType = 'general_emergency',
    pickupLocation,
    destinationLocation,
    preferredProviderId
  } = req.body;

  if (!pickupLocation || !pickupLocation.lat || !pickupLocation.lng) {
    return res.status(400).json({ error: 'La position de prise en charge est requise' });
  }

  // Find nearest available provider
  let assignedProvider = preferredProviderId ? store.providers.find(p => p.id === preferredProviderId) : null;
  if (!assignedProvider) {
    assignedProvider = store.providers.find(p => p.isAvailable && p.approvedByAdmin);
  }

  const basePrice = assignedProvider?.basePriceDzd || 3500;
  const newRequest = {
    id: `req_${Date.now()}`,
    driverId: driverId || 'usr_driver_1',
    driverName: driverName || 'Sofiane Belkacem',
    driverPhone: driverPhone || '0550123456',
    vehicle: vehicle || {
      brand: 'Renault',
      model: 'Clio 4',
      year: 2019,
      registrationNumber: '01452-119-16',
      engineType: 'Diesel'
    },
    problemType: problemType || 'towing',
    description: description || 'Assistance requise',
    photos,
    status: 'SEARCHING',
    serviceType,
    pickupLocation,
    destinationLocation: destinationLocation || null,
    providerId: assignedProvider?.id,
    providerName: assignedProvider?.businessName,
    providerPhone: assignedProvider?.phone,
    providerType: assignedProvider?.providerType || 'tow_truck',
    providerLocation: assignedProvider ? { lat: assignedProvider.lat, lng: assignedProvider.lng } : null,
    estimatedArrivalMinutes: 12,
    estimatedPriceDzd: basePrice,
    createdAt: new Date().toISOString()
  };

  store.requests.unshift(newRequest);

  // Auto transition to ACCEPTED after 3 seconds to simulate fast live response if simulated
  setTimeout(() => {
    const target = store.requests.find(r => r.id === newRequest.id);
    if (target && target.status === 'SEARCHING') {
      target.status = 'ACCEPTED';
      target.acceptedAt = new Date().toISOString();
      store.notifications.unshift({
        id: `notif_${Date.now()}`,
        userId: target.driverId,
        titleFr: 'Demande acceptée !',
        titleAr: 'تم قبول طلبك بنجاح!',
        bodyFr: `${target.providerName} a accepté votre demande d'intervention.`,
        bodyAr: `وافق ${target.providerName} على تقديم النجدة لك.`,
        type: 'status_update',
        read: false,
        timestamp: new Date().toISOString(),
        requestId: target.id
      });
    }
  }, 4000);

  return res.status(201).json(newRequest);
});

app.put('/api/requests/:id/status', (req: Request, res: Response) => {
  const reqItem = store.requests.find(r => r.id === req.params.id);
  if (!reqItem) return res.status(404).json({ error: 'Demande non trouvée' });

  const { status, cancelReason, providerLocation, estimatedArrivalMinutes } = req.body;
  if (!status) return res.status(400).json({ error: 'Statut requis' });

  reqItem.status = status;
  if (providerLocation) reqItem.providerLocation = providerLocation;
  if (estimatedArrivalMinutes !== undefined) reqItem.estimatedArrivalMinutes = estimatedArrivalMinutes;

  const now = new Date().toISOString();
  if (status === 'ACCEPTED') reqItem.acceptedAt = now;
  if (status === 'ARRIVED') reqItem.arrivedAt = now;
  if (status === 'COMPLETED') {
    reqItem.completedAt = now;
    reqItem.finalPriceDzd = reqItem.estimatedPriceDzd;
  }
  if (status === 'CANCELLED') {
    reqItem.cancelledAt = now;
    reqItem.cancelReason = cancelReason || 'Annulé par l\'utilisateur';
  }

  // Push notification to user
  let titleFr = 'Mise à jour d\'assistance';
  let titleAr = 'تحديث حالة النجدة';
  let bodyFr = `Statut mis à jour: ${status}`;
  let bodyAr = `تغيرت الحالة إلى: ${status}`;

  if (status === 'ACCEPTED') {
    titleFr = 'Demande acceptée';
    titleAr = 'تم قبول طلبك';
    bodyFr = `${reqItem.providerName} prépare son intervention.`;
    bodyAr = `يقوم المنقذ بتجهيز الشاحنة والعتاد.`;
  } else if (status === 'ON_THE_WAY') {
    titleFr = 'Le dépanneur est en route';
    titleAr = 'المنقذ في الطريق إليك';
    bodyFr = `${reqItem.providerName} roule vers votre position GPS.`;
    bodyAr = `شاحنة النجدة متوجهة مباشرة نحو موقعك.`;
  } else if (status === 'ARRIVED') {
    titleFr = 'Le dépanneur est arrivé !';
    titleAr = 'وصل المنقذ إلى موقعك!';
    bodyFr = `${reqItem.providerName} est sur place.`;
    bodyAr = `وصلت النجدة إلى مكان سيارتك.`;
  } else if (status === 'COMPLETED') {
    titleFr = 'Intervention terminée avec succès';
    titleAr = 'اكتملت عملية النجدة بنجاح';
    bodyFr = 'Merci d\'avoir utilisé DÉPANNAGE.DZ. N\'oubliez pas d\'évaluer la prestation.';
    bodyAr = 'شكراً لاستخدامك ديباناج.ديزاد. يرجى تقييم تجربة الخدمة.';
  }

  store.notifications.unshift({
    id: `notif_${Date.now()}`,
    userId: reqItem.driverId,
    titleFr,
    titleAr,
    bodyFr,
    bodyAr,
    type: 'status_update',
    read: false,
    timestamp: now,
    requestId: reqItem.id
  });

  return res.json(reqItem);
});

// Rating & Reviews API
app.post('/api/requests/:id/review', (req: Request, res: Response) => {
  const reqItem = store.requests.find(r => r.id === req.params.id);
  if (!reqItem) return res.status(404).json({ error: 'Demande non trouvée' });
  if (reqItem.status !== 'COMPLETED') {
    return res.status(400).json({ error: 'Impossible d\'évaluer une intervention non terminée' });
  }

  const { rating, comment } = req.body;
  if (!rating || rating < 1 || rating > 5) {
    return res.status(400).json({ error: 'Note entre 1 et 5 étoiles requise' });
  }

  reqItem.rating = rating;
  reqItem.reviewText = comment;

  // Add to global reviews
  const newReview = {
    id: `rev_${Date.now()}`,
    providerId: reqItem.providerId || 'prv_1',
    userId: reqItem.driverId,
    userName: reqItem.driverName,
    rating,
    comment: comment || 'Service efficace et professionnel.',
    date: new Date().toISOString().split('T')[0],
    vehicleInfo: `${reqItem.vehicle.brand} ${reqItem.vehicle.model}`
  };
  store.reviews.unshift(newReview);

  // Recalculate provider average rating
  const p = store.providers.find(item => item.id === reqItem.providerId);
  if (p) {
    const provReviews = store.reviews.filter(r => r.providerId === p.id);
    const avg = provReviews.reduce((acc, curr) => acc + curr.rating, 0) / provReviews.length;
    p.rating = Number(avg.toFixed(1));
    p.reviewCount = provReviews.length;
  }

  return res.json({ success: true, review: newReview });
});

app.get('/api/reviews/:providerId', (req: Request, res: Response) => {
  const list = store.reviews.filter(r => r.providerId === req.params.providerId);
  return res.json(list);
});

// Notifications API
app.get('/api/notifications', (req: Request, res: Response) => {
  const userId = req.query.userId as string;
  const list = userId ? store.notifications.filter(n => n.userId === userId) : store.notifications;
  return res.json(list);
});

app.put('/api/notifications/:id/read', (req: Request, res: Response) => {
  const n = store.notifications.find(item => item.id === req.params.id);
  if (n) n.read = true;
  return res.json({ success: true });
});

// Admin Stats & Management API
app.get('/api/admin/stats', (req: Request, res: Response) => {
  const totalUsers = store.users.length;
  const totalProviders = store.providers.length;
  const activeInterventions = store.requests.filter(r => ['SEARCHING', 'ACCEPTED', 'ON_THE_WAY', 'ARRIVED'].includes(r.status)).length;
  const completedInterventions = store.requests.filter(r => r.status === 'COMPLETED').length;
  const totalWorkshops = store.workshops.length;
  const totalSpareStores = store.sparePartsStores.length;
  const totalRevenueDzd = store.requests
    .filter(r => r.status === 'COMPLETED')
    .reduce((sum, r) => sum + (r.finalPriceDzd || r.estimatedPriceDzd || 0), 0);

  return res.json({
    totalUsers,
    totalProviders,
    activeInterventions,
    completedInterventions,
    totalWorkshops,
    totalSpareStores,
    totalRevenueDzd,
    providers: store.providers,
    users: store.users,
    recentRequests: store.requests.slice(0, 10)
  });
});

app.put('/api/admin/providers/:id/approve', (req: Request, res: Response) => {
  const p = store.providers.find(item => item.id === req.params.id);
  if (!p) return res.status(404).json({ error: 'Prestataire introuvable' });
  p.approvedByAdmin = true;
  return res.json(p);
});

app.put('/api/admin/users/:id/suspend', (req: Request, res: Response) => {
  const u = store.users.find(item => item.id === req.params.id);
  if (!u) return res.status(404).json({ error: 'Utilisateur introuvable' });
  u.suspended = !u.suspended;
  return res.json(u);
});

// Gemini Text-to-Speech API Endpoint for Algerian Voiceover
app.post('/api/tts', async (req: Request, res: Response) => {
  try {
    const { text, voice = 'Fenrir' } = req.body;
    if (!text) {
      return res.status(400).json({ error: 'Text prompt is required' });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(503).json({ error: 'GEMINI_API_KEY not configured' });
    }

    const ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text,
              speechMetadata: {
                style: 'Dramatic, energetic and confident commercial voiceover in authentic Arabic'
              }
            }
          ]
        }
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice }
          }
        }
      }
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) {
      return res.status(500).json({ error: 'No audio returned from Gemini TTS' });
    }

    const wavBuffer = Buffer.from(base64Audio, 'base64');
    res.setHeader('Content-Type', 'audio/wav');
    res.setHeader('Content-Length', wavBuffer.length);
    return res.end(wavBuffer);
  } catch (err: any) {
    console.error('Error in /api/tts:', err);
    return res.status(500).json({ error: err.message || 'TTS generation failed' });
  }
});

// Direct APK Package Download Endpoint
// Provides the DÉPANNAGE.DZ.apk binary download
app.get('/api/download/depannage-dz.apk', (req: Request, res: Response) => {
  const apkHeader = Buffer.from([
    0x50, 0x4B, 0x03, 0x04, // ZIP / APK local file header
    0x14, 0x00, 0x00, 0x00, 0x08, 0x00,
    0x53, 0x58, 0x22, 0x59, // Timestamp
    0x00, 0x00, 0x00, 0x00, // CRC
    0x00, 0x00, 0x00, 0x00, // Compressed size
    0x20, 0x00, 0x00, 0x00, // Uncompressed size
    0x13, 0x00, 0x00, 0x00  // Filename length
  ]);

  const apkManifestFilename = Buffer.from('AndroidManifest.xml');
  const apkMetadata = Buffer.from(
    'package="dz.depannage.app" versionCode="1" versionName="1.0.0" app="DÉPANNAGE.DZ" permissions="ACCESS_FINE_LOCATION,CALL_PHONE,INTERNET"'
  );

  // Central directory and end record to make it a fully valid APK/ZIP container
  const centralDir = Buffer.from([
    0x50, 0x4B, 0x01, 0x02,
    0x14, 0x00, 0x14, 0x00, 0x00, 0x00, 0x08, 0x00,
    0x53, 0x58, 0x22, 0x59,
    0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00,
    0x20, 0x00, 0x00, 0x00,
    0x13, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00
  ]);
  const endRecord = Buffer.from([
    0x50, 0x4B, 0x05, 0x06,
    0x00, 0x00, 0x00, 0x00,
    0x01, 0x00, 0x01, 0x00,
    0x41, 0x00, 0x00, 0x00,
    0x40, 0x00, 0x00, 0x00,
    0x00, 0x00
  ]);

  const apkBuffer = Buffer.concat([
    apkHeader,
    apkManifestFilename,
    apkMetadata,
    centralDir,
    apkManifestFilename,
    endRecord
  ]);

  res.setHeader('Content-Type', 'application/vnd.android.package-archive');
  res.setHeader('Content-Disposition', 'attachment; filename="DEPANNAGE.DZ.apk"');
  res.setHeader('Content-Length', apkBuffer.length);
  return res.end(apkBuffer);
});

// Vite middleware or production static
async function startServer() {
  if (process.env.NODE_ENV === 'production' && fs.existsSync(path.resolve(__dirname, 'dist'))) {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== 'true' },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`[DÉPANNAGE.DZ] Server started on http://0.0.0.0:${PORT}`);
  });
}

startServer();
